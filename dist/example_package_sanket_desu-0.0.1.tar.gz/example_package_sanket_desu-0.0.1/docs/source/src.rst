src package
===========

Submodules
----------

src.ingest\_data module
-----------------------

.. automodule:: src.ingest_data
   :members:
   :undoc-members:
   :show-inheritance:

src.pipeline module
-------------------

.. automodule:: src.pipeline
   :members:
   :undoc-members:
   :show-inheritance:

src.score module
----------------

.. automodule:: src.score
   :members:
   :undoc-members:
   :show-inheritance:

src.train module
----------------

.. automodule:: src.train
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src
   :members:
   :undoc-members:
   :show-inheritance:
